
module.exports = {
  generateRobotsTxt: true,
  sitemapSize: 7000
  // https://github.com/iamvishnusankar/next-sitemap#configuration-options
}