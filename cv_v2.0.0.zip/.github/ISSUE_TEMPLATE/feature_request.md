---
name: Feature request
about: Suggest a feature for me
labels: enhancement, feature

---

## Is your feature request related to a problem?

*Please describe.*

## Describe the solution you'd like



## Describe alternatives you've considered



## Additional context



#### *Thank you* for your feature request – we love each and every one!
