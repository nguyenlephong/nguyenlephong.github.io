---
name: Performance issue report
about: Long response times, high resource usage? Ensuring Dom scalable is our top priority
labels: performance
---

## In what situation are you experiencing subpar performance?

*Please describe.*

## How to reproduce

1.
2.
3.

## Environment
- [ ] App Staging
- [ ] App Live
- [ ] App Development

## Additional context



#### *Thank you* for your performance issue report – we want me to go supersonic!
